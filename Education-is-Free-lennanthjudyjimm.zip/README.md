Lennon Cruz, Jimmy Trinh, Judy Zhang, Anthony Vu

Notes:
-The animations looks better on Safari.

-The csv file is slightly edited so that the subject is on each row.

-When you restart or run the replit server, it will lag a bit upon running, leading to the videos not loading correctly for a short period of time, however, once it's up and running all functionality should be fine. This may be due to the modal.jsx taking a while to load up. If you notice that the youtube videos are not showing up, just give it a bit. 